package com.example.keyboardswitcher

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Rect
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView

/**
 * ดูว่าหน้าต่างคีย์บอร์ด (TYPE_INPUT_METHOD) กำลังแสดงอยู่หรือไม่
 * ถ้าแสดง -> วางปุ่มลอยไว้มุมขวาบนของคีย์บอร์ด
 * กดปุ่ม -> เรียกตัวเลือกสลับคีย์บอร์ดของระบบ
 * (ไม่ได้อ่านข้อความที่พิมพ์เลย ใช้แค่ตำแหน่งหน้าต่างคีย์บอร์ด)
 */
class SwitcherService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private var button: ImageView? = null
    private var params: WindowManager.LayoutParams? = null

    private val sizePx get() = (48 * resources.displayMetrics.density).toInt()
    private val marginPx get() = (8 * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refresh()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = refresh()

    override fun onInterrupt() {}

    override fun onDestroy() {
        hideButton()
        super.onDestroy()
    }

    private fun refresh() {
        val keyboard = try {
            windows.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
        } catch (e: Exception) {
            null
        }
        if (keyboard == null) {
            hideButton()
            return
        }
        val rect = Rect()
        keyboard.getBoundsInScreen(rect)
        showButton(rect)
    }

    private fun showButton(kb: Rect) {
        val x = (kb.right - sizePx - marginPx).coerceAtLeast(0)
        val y = (kb.top - sizePx - marginPx).coerceAtLeast(0)

        val existing = button
        val p = params
        if (existing != null && p != null) {
            if (p.x != x || p.y != y) {
                p.x = x
                p.y = y
                try { wm.updateViewLayout(existing, p) } catch (_: Exception) {}
            }
            return
        }

        val pad = (12 * resources.displayMetrics.density).toInt()
        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_keyboard)
            setBackgroundResource(R.drawable.bg_fab)
            setPadding(pad, pad, pad, pad)
            elevation = 6 * resources.displayMetrics.density
            contentDescription = getString(R.string.switch_keyboard)
            setOnClickListener { showPicker() }
        }
        val lp = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
        try {
            wm.addView(view, lp)
            button = view
            params = lp
        } catch (_: Exception) {
        }
    }

    private fun hideButton() {
        button?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        button = null
        params = null
    }

    private fun showPicker() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }
}
